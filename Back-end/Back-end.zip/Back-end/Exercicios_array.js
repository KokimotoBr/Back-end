//1.Crie um array com 5 nomes de colegas da sua turma.
//Exiba o nome que está na 3ª posição.
//Adicione mais um nome no final.
//Remova o primeiro nome do array.

let nomes = ["Ana", "Bruno", "Carlos", "Daniela", "Eduardo"];