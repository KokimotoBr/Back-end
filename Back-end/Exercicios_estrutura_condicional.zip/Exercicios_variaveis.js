//1. Escreva um programa que declare duas variáveis, “nome” e “idade”, e as imprima em um console em uma frase que diga “Olá, meu nome é [nome] e eu tenho [idade] anos

let nome = "Kokimoto";
let idade = 15;
console.log("Olá, meu nome é nome", nome, "e eu tenho", idade, "anos.");

//2. Declare uma string e utilize métodos para converter para maiúsculas e minúsculas.

let coisa = "Objeto Legal";
console.log(coisa.toLowerCase());
console.log(coisa.toUpperCase());

//3. Declare uma variável e verifique se o tipo dela é number.

let número = 4;
console.log(typeof número);

//4. Calcule o Índice de Massa Corporal (IMC) utilizando variáveis para altura e peso.

let altura = 1.60;
let peso = 50.40;
console.log(altura / peso);