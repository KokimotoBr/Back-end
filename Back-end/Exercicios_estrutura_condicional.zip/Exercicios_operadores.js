<<<<<<< HEAD
//1. Crie um programa que declare duas variáveis e exiba o resultado da soma, subtração, multiplicação e divisão desses números.

let n1 = 6;
let n2 = 2;

console.log(`${n1} + ${n2} = ${n1+n2}`);
console.log(`${n1} - ${n2} = ${n1-n2}`);
console.log(`${n1} * ${n2} = ${n1*n2}`);
console.log(`${n1} / ${n2} = ${n1/n2}`);

//2. Declare duas idades e utilize operadores de comparação para verificar se uma pessoa é mais velha que a outra.

let id1 = 17;
let id2 = 20;
console.log(id1 > id2);
console.log(id1 < id2);

//3. Crie uma variável idade com um número e use o operador ternário para verificar se o valor armazenado na variável é maior ou igual a 18. Imprima “Maior de idade” ou “Menor de idade”.

let id3 = 15;
aviso = id3 >= 18 ? "Maior de idade" : "Menor de idade";
console.log(aviso);

//4. Crie uma variável com um número e use o operador ternário para verificar se é par ou ímpar.

let n3 = 2;
let conta = n3 %2 == 0 ? "Par" : "ímpar";
=======
//1. Crie um programa que declare duas variáveis e exiba o resultado da soma, subtração, multiplicação e divisão desses números.

let n1 = 6;
let n2 = 2;

console.log(`${n1} + ${n2} = ${n1+n2}`);
console.log(`${n1} - ${n2} = ${n1-n2}`);
console.log(`${n1} * ${n2} = ${n1*n2}`);
console.log(`${n1} / ${n2} = ${n1/n2}`);

//2. Declare duas idades e utilize operadores de comparação para verificar se uma pessoa é mais velha que a outra.

let id1 = 17;
let id2 = 20;
console.log(id1 > id2);
console.log(id1 < id2);

//3. Crie uma variável idade com um número e use o operador ternário para verificar se o valor armazenado na variável é maior ou igual a 18. Imprima “Maior de idade” ou “Menor de idade”.

let id3 = 15;
aviso = id3 >= 18 ? "Maior de idade" : "Menor de idade";
console.log(aviso);

//4. Crie uma variável com um número e use o operador ternário para verificar se é par ou ímpar.

let n3 = 2;
let conta = n3 %2 == 0 ? "Par" : "ímpar";
>>>>>>> a6e9adc441205cc5c26420363d3d3f4ac0a31e45
console.log(conta);