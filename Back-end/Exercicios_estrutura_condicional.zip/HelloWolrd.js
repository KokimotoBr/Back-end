<<<<<<< HEAD
console.log("Hello, Wolrd!");

let expressao = 1

=======
console.log("Hello, Wolrd!");
>>>>>>> a6e9adc441205cc5c26420363d3d3f4ac0a31e45
